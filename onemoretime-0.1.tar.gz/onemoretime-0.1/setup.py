from setuptools import setup

setup(
    name="onemoretime",
    version="0.1",
    author="Your Name",
    author_email="yyour@email.com",
    description="A simple Python package",
    packages=["onemoretime"],
)
